"use client";

import { useLocaleStore } from "./store";
import fr, { type Messages } from "./messages/fr";
import en from "./messages/en";

const dictionaries = { fr, en };

// Renvoie l'objet de traduction complet pour un espace de nom donné, pas
// une fonction `t(clé)` à chemin textuel : les fautes de frappe et les
// clés manquantes se voient à la compilation (autocomplétion TypeScript
// incluse) plutôt qu'au runtime sous forme de texte manquant à l'écran.
//
// Le type de retour vise `Messages[K]` (la forme assouplie — mêmes clés,
// n'importe quel `string`), pas `(typeof fr)[K]` : ce dernier exigerait
// littéralement le texte français exact, ce que le dictionnaire anglais
// ne peut évidemment pas satisfaire.
export function useTranslations<K extends keyof typeof fr>(namespace: K): Messages[K] {
  const locale = useLocaleStore((s) => s.locale);
  // Cast explicite : TypeScript n'arrive pas à prouver qu'indexer une union
  // (`typeof fr | typeof en`) par `namespace` correspond à `Messages[K]`,
  // même si c'est vrai par construction — `en` satisfait déjà `Messages`
  // (vérifié dans en.ts via `satisfies Messages`), donc ce cast ne masque
  // aucune vraie erreur de type, juste une limite de l'inférence sur les
  // unions indexées.
  return dictionaries[locale][namespace] as Messages[K];
}