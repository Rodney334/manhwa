// Dictionnaire français — un espace de nom par page/composant migré.
// Ajouté au fur et à mesure des pages traduites, pas tout d'un coup : plus
// sûr sur un projet de cette taille que de tout migrer en une seule passe.
const fr = {
  landing: {
    nav: { features: "Fonctionnalités", stats: "En chiffres" },
    login: "Se connecter",
    eyebrow: "catalogue commun · sans doublon",
    titlePrefix: "Ne perdez plus jamais ",
    titleEm: "le fil",
    titleSuffix: ".",
    subtitle:
      "Une bibliothèque unique pour tous vos manhwas, manhuas et webtoons en cours. Suivez votre progression, retrouvez où vous en étiez, et ne relisez jamais deux fois le même chapitre.",
    ctaRegister: "Créer un compte gratuit",
    ctaHaveAccount: "J'ai déjà un compte",
    featuresEyebrow: "fonctionnalités",
    featuresTitle: "Tout ce qu'il faut, rien de plus.",
    featuresDesc:
      "Une interface pensée pour la lecture régulière : reprendre vite, ajouter en un geste, et une vue d'ensemble toujours à jour.",
    features: [
      {
        icon: "◐",
        title: "Reprendre",
        text: "Trié par retard, pas par date : la série la plus en arrière est celle qu'on abandonne.",
      },
      {
        icon: "+1",
        title: "+1 en un geste",
        text: "Avance ta progression sans quitter la liste. Un tap, un chapitre de plus.",
      },
      {
        icon: "▦",
        title: "Bibliothèque",
        text: "En cours, en pause, terminé, abandonné, à lire — filtre par statut, genre ou favoris.",
      },
      {
        icon: "⌕",
        title: "Recherche",
        text: "Titre, titre alternatif ou auteur, sur tout le catalogue commun.",
      },
      {
        icon: "◉",
        title: "Notifications",
        text: "Un nouveau chapitre sort, tu le sais — sans avoir à revérifier chaque série un par un.",
      },
      {
        icon: "↗",
        title: "Partage",
        text: "Un lien public, en lecture seule, vers ta bibliothèque. Rien à installer côté visiteur.",
      },
      {
        icon: "◧",
        title: "Statistiques",
        text: "Chapitres lus, note moyenne, répartition par statut — ta lecture, en chiffres.",
      },
    ],
    statsEyebrow: "en chiffres",
    statsTitle: "Un catalogue qui grandit avec ses lecteurs.",
    statDuplicates: { value: "0 doublon", text: "Dédoublonnage automatique à la soumission d'une fiche." },
    statSources: { value: "3 sources", text: "MangaDex, AniList et Jikan pour importer une fiche en un clic." },
    statFree: { value: "100% gratuit", text: "Aucune fonctionnalité de suivi cachée derrière un abonnement." },
    finalTitle: "Reprends là où tu t'es arrêté.",
    finalSubtitle: "Trois champs pour créer ton compte. Pas d'e-mail de confirmation à attendre.",
    finalCta: "Commencer",
    footerTagline: "Fait pour les lecteurs qui suivent trop de séries à la fois.",
    footerTerms: "Conditions générales d'utilisation",
  },
  auth: {
    showPassword: "Afficher le mot de passe",
    hidePassword: "Masquer le mot de passe",
    login: {
      title: "Connexion",
      subtitle: "Ton pseudo ou ton adresse, peu importe lequel.",
      identifierLabel: "Identifiant",
      identifierPlaceholder: "kofi_reads ou kofi@exemple.bj",
      passwordLabel: "Mot de passe",
      forgotPassword: "Mot de passe oublié ?",
      submit: "Se connecter",
      welcomeBack: "Content de te revoir, {name}.",
      genericError: "Connexion impossible. Réessaie.",
      noAccount: "Pas encore de compte ?",
      signUp: "Inscris-toi",
    },
    register: {
      title: "Inscription",
      subtitle: "Trois champs, rien de plus. 8 caractères minimum, une lettre, un chiffre.",
      usernameLabel: "Nom d'utilisateur",
      usernamePlaceholder: "kofi_reads",
      usernameHint: "Lettres, chiffres et tiret bas uniquement — accents acceptés, pas d'espaces.",
      emailLabel: "Adresse e-mail",
      emailPlaceholder: "kofi@exemple.bj",
      passwordLabel: "Mot de passe",
      termsPrefix: "J'ai lu et j'accepte les",
      termsLink: "conditions générales d'utilisation",
      submit: "Créer mon compte",
      welcome: "Bienvenue sur ManhwaList.",
      genericError: "Inscription impossible. Réessaie.",
      haveAccount: "Déjà un compte ?",
      logIn: "Connecte-toi",
      fieldLabels: {
        username: "Nom d'utilisateur",
        email: "Adresse e-mail",
        password: "Mot de passe",
      },
    },
    forgotPassword: {
      title: "Mot de passe oublié",
      subtitle: "On t'envoie un code de réinitialisation valable une heure.",
      emailLabel: "Adresse e-mail",
      submit: "Envoyer le code",
      backToLogin: "Retour à la connexion",
      genericError: "Une erreur est survenue. Réessaie.",
      sentTitle: "Vérifie ta boîte mail",
      sentBodyPrefix: "Si un compte correspond à",
      sentBodySuffix: ", un code de réinitialisation valable une heure vient d'être envoyé.",
      spamHint: "Rien reçu après quelques minutes ? Vérifie ton dossier",
      spamHintBold: "spams / courrier indésirable",
      spamHintSuffix: "— les codes de réinitialisation y atterrissent parfois.",
      gotCode: "J'ai reçu mon code",
    },
    resetPassword: {
      title: "Nouveau mot de passe",
      subtitle: "Colle le code reçu par e-mail et choisis un nouveau mot de passe.",
      noEmailPrefix: "Pas de trace du mail ? Regarde du côté des",
      noEmailBold: "spams / courrier indésirable",
      codeLabel: "Code reçu par e-mail",
      newPasswordLabel: "Nouveau mot de passe",
      passwordHint: "8 caractères minimum, au moins une lettre et un chiffre.",
      submit: "Réinitialiser le mot de passe",
      genericError: "Code invalide ou expiré. Réessaie.",
      successToast: "Mot de passe réinitialisé. Connecte-toi avec ton nouveau mot de passe.",
      noCode: "Pas de code ?",
      resend: "Redemander un envoi",
    },
  },
  sidebar: {
    sectionRead: "Lire",
    sectionAccount: "Compte",
    sectionAdmin: "Administration",
    resume: "Reprendre",
    library: "Bibliothèque",
    search: "Chercher",
    calendar: "Calendrier",
    discover: "Découvrir",
    stats: "Statistiques",
    notifications: "Notifications",
    share: "Partage",
    profile: "Profil",
    admin: "Administrateur",
    reader: "Lecteur",
    logout: "Se déconnecter",
    overview: "Vue d'ensemble",
    moderation: "Modération",
    accounts: "Comptes",
    journal: "Journal",
    tasks: "Tâches",
    closeMenu: "Fermer le menu",
    openMenu: "Ouvrir le menu",
  },
  topbar: {
    openMenu: "Ouvrir le menu",
    searchPlaceholder: "Chercher un manhwa…",
    notifications: "Notifications",
    newEntry: "Nouvelle fiche",
  },
  resume: {
    days: ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"],
    months: [
      "janvier", "février", "mars", "avril", "mai", "juin",
      "juillet", "août", "septembre", "octobre", "novembre", "décembre",
    ],
    title: "Reprendre",
    subtitle: "Trié par retard, pas par date : la série la plus en arrière est celle qu'on abandonne.",
    loadError: "Impossible de charger ta reprise.",
    loadErrorRetryText: "Impossible de charger ta reprise pour l'instant.",
    retry: "Réessayer",
    caughtUpTitle: "Tu as tout repris pour l'instant",
    caughtUpSubtitle: "Reviens ici dès qu'un nouveau chapitre sort sur l'une de tes séries en cours.",
    seeBacklogAnyway: "Voir tout mon retard quand même",
    emptyTitle: "Rien à reprendre pour l'instant",
    emptySubtitle: "Ajoute des séries à ta bibliothèque pour les retrouver ici, triées par retard de lecture.",
    searchManhwa: "Chercher un manhwa",
    incrementSuccess: "+1 chapitre",
    alreadyUpToDate: "Tu es déjà à jour sur cette série.",
    updateError: "Échec de la mise à jour.",
    quest: {
      title: "Quête du jour",
      titleDone: "Quête du jour accomplie",
      subtitleDone: "Reviens demain pour continuer ta série.",
      subtitle: "N'importe laquelle des trois suffit.",
      read: "Lire un chapitre",
      added: "Ajouter une série",
      finished: "Terminer une série",
    },
  },
} as const;

// `as const` fige chaque texte français comme type littéral exact (ex.
// "En chiffres" et pas juste `string`) — utile pour l'autocomplétion des
// clés dans `useTranslations`, mais ça bloquerait `en.ts` si on l'utilisait
// tel quel : il exigerait alors le MÊME texte, pas la même forme. `Widen`
// ramène chaque chaîne littérale à `string` tout en gardant la structure
// (clés, imbrication, tableaux) — c'est CETTE version que le dictionnaire
// anglais doit respecter.
type Widen<T> = T extends string
  ? string
  : T extends readonly (infer U)[]
    ? readonly Widen<U>[]
    : T extends object
      ? { [K in keyof T]: Widen<T[K]> }
      : T;

export type Messages = Widen<typeof fr>;
export default fr;